import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchQuizzes = createAsyncThunk('quizzes/fetchQuizzes', async () => {
  const response = await axios.get('/api/quizzes');
  return response.data;
});

const quizzesSlice = createSlice({
  name: 'quizzes',
  initialState: { items: [], status: 'idle', error: null },
  extraReducers: (builder) => {
    builder
      .addCase(fetchQuizzes.fulfilled, (state, action) => {
        state.items = action.payload;
      });
  },
});

export default quizzesSlice.reducer;
