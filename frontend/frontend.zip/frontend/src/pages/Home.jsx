import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchQuizzes } from '../features/quizzes/quizzesSlice';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const quizzes = useSelector((state) => state.quizzes.items);
  const user = useSelector((state) => state.auth.user);

  useEffect(() => {
    dispatch(fetchQuizzes());
  }, [dispatch]);

  const handleQuizClick = (quizId) => {
    if (user) {
      navigate(`/quiz/${quizId}`);
    } else {
      navigate('/login');
    }
  };

  return (
    <div>
      <h1>All Quizzes</h1>
      <ul>
        {quizzes.map((quiz) => (
          <li key={quiz.id} onClick={() => handleQuizClick(quiz.id)}>
            {quiz.title}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;
