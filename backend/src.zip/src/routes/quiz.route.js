import express from 'express';
import { getAllQuizzes,getQuizById } from '../controllers/quiz.controller.js';
const router = express.Router();

router.get('/', getAllQuizzes);
router.get('/:id', getQuizById);


export default router;
