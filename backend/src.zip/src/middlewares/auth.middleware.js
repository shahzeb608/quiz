import jwt from "jsonwebtoken";
import { User } from "../models/user.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const protect = asyncHandler(async (req, res, next) => {
  const tokenHeader = req.headers.authorization;

  if (!tokenHeader || !tokenHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Unauthorized - No Token" });
  }

  try {
    const token = tokenHeader.split(" ")[1];
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    req.user = await User.findById(decoded.id).select("-password");

    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized - User Not Found" });
    }

    console.log("Authenticated User:", req.user);
    next();
  } catch (error) {
    console.error("Token verification failed:", error);
    res.status(401).json({ message: "Unauthorized - Invalid Token" });
  }
});

export const isAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== "admin") {
    console.log("Access Denied - User Role:", req.user ? req.user.role : "No User Data");
    return res.status(403).json({ message: "Access Denied - Admins Only" });
  }

  next();
};
