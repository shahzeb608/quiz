import mongoose, { Schema } from "mongoose";

const LeaderboardSchema = new Schema(
  {
    username: { type: String, required: true },
    quizId: { type: Schema.Types.ObjectId, ref: "Quiz", required: true, index: true },
    score: { type: Number, required: true, min: 0 },
    attemptedAt: { type: Date, default: Date.now, index: true }
  },
  {
    timestamps: true
  }
);

export default mongoose.model("Leaderboard", LeaderboardSchema);
